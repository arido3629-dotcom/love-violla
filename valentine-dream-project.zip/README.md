# 💗 Valentine Dream

Website Valentine interaktif yang dibuat dari HTML, CSS, dan JavaScript murni.

## Fitur
- Landing page romantis
- Pertanyaan Valentine dengan tombol "kabur"
- Love Meter animasi sampai 100%
- Pesan typewriter
- Galeri kenangan
- Animasi hati melayang
- Responsive untuk HP dan desktop
- Tidak membutuhkan framework atau database

## Menjalankan
Buka `index.html` langsung di browser, atau gunakan Live Server di VS Code.

## Upload ke GitHub
1. Buat repository baru, misalnya `valentine-dream`.
2. Upload semua file dan folder dari project ini.
3. Commit perubahan.
4. Untuk membuat website online, aktifkan GitHub Pages dari Settings → Pages dan pilih branch `main` serta folder `/ (root)`.

Dibuat dengan ❤️.
