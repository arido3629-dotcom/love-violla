const screens=[...document.querySelectorAll(".screen")];
const hearts=document.getElementById("hearts");
function goTo(id){
  screens.forEach(s=>s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
  if(id==="meter") startMeter();
  if(id==="message") typeMessage();
}
function yesAnswer(){goTo("meter")}
function moveNo(){
  const b=document.getElementById("noBtn");
  b.style.position="relative";
  b.style.left=(Math.random()*180-90)+"px";
  b.style.top=(Math.random()*100-50)+"px";
}
function startMeter(){
  const value=document.getElementById("meterValue"), text=document.getElementById("meterText"), next=document.getElementById("meterNext");
  let n=0; next.disabled=true;
  const timer=setInterval(()=>{
    n+=Math.floor(Math.random()*8)+2;
    if(n>=100){n=100;clearInterval(timer);next.disabled=false;text.textContent="Ternyata tidak cukup angka untuk mengukur rasa ini. ♡"}
    value.textContent=n+"%";
  },90);
}
function typeMessage(){
  const el=document.getElementById("typewriter");
  if(el.dataset.done)return;
  el.dataset.done="1";
  const msg="Kalau ada satu hal yang ingin aku katakan hari ini, itu adalah: terima kasih sudah hadir. Kamu membuat hari-hari biasa terasa sedikit lebih indah, percakapan sederhana terasa lebih berarti, dan senyum datang tanpa alasan.";
  let i=0;el.textContent="";
  const timer=setInterval(()=>{el.textContent+=msg[i++];if(i>=msg.length)clearInterval(timer)},24);
}
function restart(){goTo("hero")}
function makeHeart(){
  const h=document.createElement("span");h.className="heart";h.textContent=Math.random()>.5?"♥":"♡";
  h.style.left=Math.random()*100+"vw";h.style.fontSize=(10+Math.random()*18)+"px";h.style.animationDuration=(5+Math.random()*5)+"s";
  hearts.appendChild(h);setTimeout(()=>h.remove(),10000);
}
setInterval(makeHeart,650);
